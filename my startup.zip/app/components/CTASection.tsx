
'use client';

import Link from 'next/link';

export default function CTASection() {
  return (
    <section className="py-20 bg-blue-600">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Take Control of Your Health?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Join millions of Indians who trust HealthYatra for their healthcare needs. Start your journey to better health today.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/signup" className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-blue-50 transition-colors cursor-pointer text-center whitespace-nowrap">
              Get Started Free
            </Link>
            <Link href="/doctors" className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer text-center whitespace-nowrap">
              Find Doctors Now
            </Link>
          </div>
          
          <p className="text-blue-200 mt-6 text-sm">
            No credit card required • Free for patients • Available 24/7
          </p>
        </div>
      </div>
    </section>
  );
}
