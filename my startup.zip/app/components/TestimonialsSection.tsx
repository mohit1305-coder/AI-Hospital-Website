
'use client';

export default function TestimonialsSection() {
  const testimonials = [
    {
      name: 'Priya Sharma',
      location: 'Mumbai, Maharashtra',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20woman%20in%20her%2030s%2C%20friendly%20smile%2C%20modern%20office%20setting%2C%20business%20casual%20attire%2C%20confident%20and%20approachable%20expression%2C%20natural%20lighting%2C%20clean%20background%20representing%20healthcare%20patient%20satisfaction%20and%20trust&width=80&height=80&seq=avatar-priya-1&orientation=squarish',
      rating: 5,
      text: 'HealthYatra made it so easy to find a cardiologist in my area. The booking process was seamless, and I got my appointment within 24 hours. Highly recommend!'
    },
    {
      name: 'Rajesh Kumar',
      location: 'Delhi, India',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20man%20in%20his%2040s%2C%20warm%20smile%2C%20business%20casual%20shirt%2C%20approachable%20demeanor%2C%20modern%20office%20background%2C%20natural%20lighting%2C%20representing%20satisfied%20healthcare%20patient%20with%20positive%20experience&width=80&height=80&seq=avatar-rajesh-1&orientation=squarish',
      rating: 5,
      text: 'As someone from a small town, finding quality healthcare was always a challenge. HealthYatra connected me with excellent doctors in nearby cities. Life-changing service!'
    },
    {
      name: 'Dr. Anita Patel',
      location: 'Bangalore, Karnataka',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20female%20doctor%20in%20white%20coat%2C%20stethoscope%20around%20neck%2C%20confident%20smile%2C%20medical%20office%20background%2C%20representing%20healthcare%20professional%20satisfied%20with%20platform%20service%2C%20clean%20modern%20setting&width=80&height=80&seq=avatar-anita-1&orientation=squarish',
      rating: 5,
      text: 'From a doctor\'s perspective, HealthYatra has streamlined my practice. The platform is user-friendly and helps me reach patients who truly need my expertise.'
    },
    {
      name: 'Arjun Mehta',
      location: 'Ahmedabad, Gujarat',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20Indian%20man%20in%20his%2020s%2C%20casual%20shirt%2C%20friendly%20expression%2C%20modern%20background%2C%20representing%20satisfied%20healthcare%20patient%2C%20natural%20lighting%2C%20clean%20setting%20showing%20positive%20healthcare%20experience&width=80&height=80&seq=avatar-arjun-1&orientation=squarish',
      rating: 5,
      text: 'The emergency care feature saved my life! I was able to quickly locate the nearest hospital during a medical emergency. Thank you HealthYatra team!'
    },
    {
      name: 'Meera Reddy',
      location: 'Hyderabad, Telangana',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20woman%20in%20her%2050s%2C%20traditional%20yet%20modern%20attire%2C%20warm%20smile%2C%20representing%20mature%20healthcare%20patient%2C%20comfortable%20home%20setting%2C%20natural%20lighting%2C%20showing%20satisfaction%20with%20medical%20services&width=80&height=80&seq=avatar-meera-1&orientation=squarish',
      rating: 5,
      text: 'Managing my elderly mother\'s appointments became so much easier with HealthYatra. The reminder system and follow-up features are excellent for senior care.'
    },
    {
      name: 'Vikram Singh',
      location: 'Jaipur, Rajasthan',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20man%20in%20his%2030s%2C%20business%20shirt%2C%20confident%20expression%2C%20modern%20office%20setting%2C%20representing%20satisfied%20healthcare%20patient%20with%20positive%20experience%2C%20natural%20lighting%2C%20clean%20background&width=80&height=80&seq=avatar-vikram-1&orientation=squarish',
      rating: 5,
      text: 'The telemedicine feature is fantastic! I can consult with my doctor without traveling to the city. Perfect for busy professionals like me.'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            What Our Users Say
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Real stories from patients, doctors, and healthcare providers who have experienced the HealthYatra difference.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-4">
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover object-top mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-gray-600">{testimonial.location}</p>
                </div>
              </div>
              
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-yellow-400 text-sm"></i>
                ))}
              </div>
              
              <p className="text-gray-700 leading-relaxed">
                "{testimonial.text}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
