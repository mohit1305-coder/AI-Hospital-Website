
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <Link href="/" className="text-2xl font-bold text-blue-400 mb-4 block" style={{ fontFamily: 'Pacifico, serif' }}>
              HealthYatra
            </Link>
            <p className="text-gray-400 mb-6">
              Making quality healthcare accessible to everyone across India. Your health journey starts here.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-8 h-8 flex items-center justify-center bg-gray-800 rounded-full hover:bg-blue-600 transition-colors cursor-pointer">
                <i className="ri-facebook-fill text-sm"></i>
              </a>
              <a href="#" className="w-8 h-8 flex items-center justify-center bg-gray-800 rounded-full hover:bg-blue-600 transition-colors cursor-pointer">
                <i className="ri-twitter-fill text-sm"></i>
              </a>
              <a href="#" className="w-8 h-8 flex items-center justify-center bg-gray-800 rounded-full hover:bg-blue-600 transition-colors cursor-pointer">
                <i className="ri-instagram-line text-sm"></i>
              </a>
              <a href="#" className="w-8 h-8 flex items-center justify-center bg-gray-800 rounded-full hover:bg-blue-600 transition-colors cursor-pointer">
                <i className="ri-linkedin-fill text-sm"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              <li><Link href="/doctors" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Find Doctors</Link></li>
              <li><Link href="/hospitals" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Hospitals</Link></li>
              <li><Link href="/emergency" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Emergency Care</Link></li>
              <li><Link href="/telemedicine" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Telemedicine</Link></li>
              <li><Link href="/diagnostics" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Diagnostics</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-gray-400 hover:text-white transition-colors cursor-pointer">About Us</Link></li>
              <li><Link href="/careers" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Careers</Link></li>
              <li><Link href="/blog" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Blog</Link></li>
              <li><Link href="/press" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Press</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li><Link href="/help" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Help Center</Link></li>
              <li><Link href="/privacy" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Privacy Policy</Link></li>
              <li><Link href="/terms" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Terms of Service</Link></li>
              <li><Link href="/security" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Security</Link></li>
              <li><Link href="/feedback" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Feedback</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 HealthYatra. All rights reserved. • Made with ❤️ for better healthcare access in India.
          </p>
        </div>
      </div>
    </footer>
  );
}
