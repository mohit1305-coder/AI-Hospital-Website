
'use client';

export default function ServicesSection() {
  const services = [
    {
      title: 'General Practice',
      description: 'Connect with family doctors and general practitioners for routine checkups and primary care.',
      image: 'https://readdy.ai/api/search-image?query=Professional%20family%20doctor%20in%20white%20coat%20consulting%20with%20patient%20in%20bright%20modern%20clinic%2C%20stethoscope%20around%20neck%2C%20warm%20friendly%20smile%2C%20medical%20charts%20on%20desk%2C%20comfortable%20examination%20room%20with%20natural%20lighting%2C%20plants%20in%20background%2C%20representing%20trust%20and%20primary%20healthcare&width=400&height=300&seq=service-general-1&orientation=landscape'
    },
    {
      title: 'Specialist Consultations',
      description: 'Book appointments with specialists including cardiologists, dermatologists, and orthopedic surgeons.',
      image: 'https://readdy.ai/api/search-image?query=Medical%20specialist%20doctor%20examining%20patient%20with%20advanced%20medical%20equipment%2C%20modern%20examination%20room%2C%20sophisticated%20medical%20instruments%2C%20professional%20healthcare%20setting%2C%20specialist%20consultation%20in%20progress%2C%20clean%20white%20environment%20with%20medical%20charts%20and%20screens&width=400&height=300&seq=service-specialist-1&orientation=landscape'
    },
    {
      title: 'Diagnostic Services',
      description: 'Schedule lab tests, X-rays, and other diagnostic procedures at certified medical facilities.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20medical%20laboratory%20with%20advanced%20diagnostic%20equipment%2C%20medical%20technician%20in%20white%20coat%20analyzing%20samples%2C%20sophisticated%20medical%20instruments%2C%20clean%20sterile%20environment%2C%20test%20tubes%20and%20medical%20machinery%2C%20professional%20lab%20setting%20with%20bright%20lighting&width=400&height=300&seq=service-diagnostic-1&orientation=landscape'
    },
    {
      title: 'Emergency Care',
      description: 'Find nearby emergency services and urgent care centers for immediate medical attention.',
      image: 'https://readdy.ai/api/search-image?query=Emergency%20medical%20team%20in%20action%2C%20ambulance%20and%20hospital%20emergency%20entrance%2C%20medical%20professionals%20in%20scrubs%20rushing%20to%20help%2C%20modern%20emergency%20room%20with%20advanced%20life%20support%20equipment%2C%20bright%20medical%20facility%2C%20urgent%20care%20setting%20with%20medical%20staff&width=400&height=300&seq=service-emergency-1&orientation=landscape'
    },
    {
      title: 'Mental Health',
      description: 'Access mental health professionals and counselors for psychological support and therapy.',
      image: 'https://readdy.ai/api/search-image?query=Calm%20therapy%20session%20with%20mental%20health%20counselor%20and%20patient%20in%20comfortable%20office%20setting%2C%20soft%20lighting%2C%20peaceful%20atmosphere%2C%20professional%20therapist%20in%20casual%20attire%2C%20comfortable%20chairs%2C%20plants%20and%20books%2C%20representing%20mental%20wellness%20and%20support&width=400&height=300&seq=service-mental-1&orientation=landscape'
    },
    {
      title: 'Telemedicine',
      description: 'Consult with doctors remotely through video calls for convenient healthcare access.',
      image: 'https://readdy.ai/api/search-image?query=Doctor%20conducting%20video%20consultation%20on%20laptop%2C%20professional%20medical%20office%20setup%2C%20modern%20technology%20for%20telemedicine%2C%20patient%20visible%20on%20screen%2C%20clean%20desk%20with%20medical%20supplies%2C%20digital%20healthcare%20concept%2C%20remote%20medical%20consultation%20in%20progress&width=400&height=300&seq=service-telemedicine-1&orientation=landscape'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Our Healthcare Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive medical services at your fingertips. From routine checkups to specialized care, we connect you with the right healthcare providers.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-sm hover:shadow-lg transition-shadow overflow-hidden border border-gray-100">
              <div className="h-48 bg-gray-100 overflow-hidden">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {service.title}
                </h3>
                <p className="text-gray-600 leading-relaxed mb-4">
                  {service.description}
                </p>
                <button className="text-blue-600 font-medium hover:text-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                  Learn More →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
