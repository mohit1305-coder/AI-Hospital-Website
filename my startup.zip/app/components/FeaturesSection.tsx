
'use client';

export default function FeaturesSection() {
  const features = [
    {
      icon: 'ri-calendar-check-line',
      title: 'Easy Appointment Booking',
      description: 'Book appointments with your preferred doctors and hospitals in just a few clicks. No more long waiting times or phone calls.'
    },
    {
      icon: 'ri-user-heart-line',
      title: 'Trusted Healthcare Providers',
      description: 'Access verified doctors and hospitals with patient reviews and ratings to make informed healthcare decisions.'
    },
    {
      icon: 'ri-smartphone-line',
      title: 'Mobile-First Experience',
      description: 'Manage your health on the go with our intuitive mobile platform designed for urban and rural users alike.'
    },
    {
      icon: 'ri-map-pin-line',
      title: 'Location-Based Search',
      description: 'Find healthcare providers near you or in your preferred location with real-time availability updates.'
    },
    {
      icon: 'ri-time-line',
      title: 'Real-Time Scheduling',
      description: 'View real-time availability and get instant confirmation for your appointments with automatic reminders.'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Secure & Private',
      description: 'Your health information is protected with end-to-end encryption and strict privacy compliance.'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Why Choose HealthYatra?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We're revolutionizing healthcare access in India by making it easier, faster, and more convenient to connect with quality medical care.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-full mb-6">
                <i className={`${feature.icon} text-2xl text-blue-600`}></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
