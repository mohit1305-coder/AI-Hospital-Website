
'use client';

export default function StatsSection() {
  const stats = [
    {
      number: '50,000+',
      label: 'Verified Doctors',
      description: 'Trusted healthcare professionals across India'
    },
    {
      number: '1,200+',
      label: 'Partner Hospitals',
      description: 'Quality healthcare facilities nationwide'
    },
    {
      number: '2M+',
      label: 'Happy Patients',
      description: 'Successful appointments and consultations'
    },
    {
      number: '500+',
      label: 'Cities Covered',
      description: 'Expanding healthcare access across India'
    }
  ];

  return (
    <section className="py-20 bg-blue-600">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Trusted by Millions
          </h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Join millions of Indians who trust HealthYatra for their healthcare needs. Our growing network ensures quality care is always within reach.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-5xl md:text-6xl font-bold text-white mb-4">
                {stat.number}
              </div>
              <div className="text-xl font-semibold text-blue-100 mb-2">
                {stat.label}
              </div>
              <p className="text-blue-200">
                {stat.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
