
'use client';

import Link from 'next/link';

export default function HeroSection() {
  return (
    <section 
      className="relative bg-cover bg-center bg-no-repeat min-h-screen flex items-center"
      style={{
        backgroundImage: `linear-gradient(135deg, rgba(59, 130, 246, 0.9) 0%, rgba(37, 99, 235, 0.8) 100%), url('https://readdy.ai/api/search-image?query=Modern%20healthcare%20facility%20with%20clean%20white%20corridors%2C%20professional%20medical%20environment%2C%20soft%20natural%20lighting%20streaming%20through%20large%20windows%2C%20doctors%20and%20nurses%20in%20white%20coats%20walking%20confidently%2C%20patients%20feeling%20comfortable%20and%20safe%2C%20state-of-the-art%20medical%20equipment%20visible%20in%20background%2C%20welcoming%20reception%20area%20with%20plants%20and%20modern%20furniture%2C%20peaceful%20atmosphere%20representing%20trust%20and%20care%20in%20healthcare&width=1920&height=1080&seq=hero-healthcare-1&orientation=landscape')`
      }}
    >
      <div className="container mx-auto px-4 py-20">
        <div className="w-full max-w-4xl">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Book Your Healthcare Appointments
            <span className="text-blue-200 block">Anytime, Anywhere</span>
          </h1>
          <p className="text-xl md:text-2xl text-blue-100 mb-8 max-w-2xl">
            Connect with trusted doctors and hospitals across India. Schedule appointments, get consultations, and manage your health journey with ease.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/doctors" className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-blue-50 transition-colors cursor-pointer text-center whitespace-nowrap">
              Find Doctors
            </Link>
            <Link href="/hospitals" className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer text-center whitespace-nowrap">
              Browse Hospitals
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
