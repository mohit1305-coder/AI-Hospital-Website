
'use client';

import Header from '../components/Header';
import Footer from '../components/Footer';
import DoctorSearch from './DoctorSearch';
import DoctorList from './DoctorList';

export default function DoctorsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main>
        <div className="bg-blue-600 text-white py-16">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Find Your Doctor</h1>
            <p className="text-xl text-blue-100 max-w-2xl">
              Search and book appointments with verified doctors across India. Choose from thousands of specialists and general practitioners.
            </p>
          </div>
        </div>
        
        <DoctorSearch />
        <DoctorList />
      </main>
      <Footer />
    </div>
  );
}
