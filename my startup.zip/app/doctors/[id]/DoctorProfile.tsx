
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import AppointmentBooking from './AppointmentBooking';

interface DoctorProfileProps {
  doctorId: string;
}

export default function DoctorProfile({ doctorId }: DoctorProfileProps) {
  const [showBooking, setShowBooking] = useState(false);

  const doctor = {
    id: doctorId,
    name: 'Dr. Priya Sharma',
    specialty: 'Cardiology',
    experience: '15 years',
    rating: 4.8,
    reviews: 234,
    location: 'Mumbai, Maharashtra',
    hospital: 'Apollo Hospital',
    fee: '₹800',
    image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20female%20doctor%20in%20white%20coat%2C%20stethoscope%20around%20neck%2C%20warm%20smile%2C%20modern%20medical%20office%20background%2C%20confident%20and%20approachable%2C%20medical%20charts%20visible%2C%20representing%20cardiology%20specialist&width=200&height=200&seq=doctor-profile-1&orientation=squarish',
    about: 'Dr. Priya Sharma is a highly experienced cardiologist with over 15 years of expertise in interventional cardiology and heart surgeries. She has performed over 2000 successful cardiac procedures and is known for her compassionate care and patient-centered approach.',
    languages: ['English', 'Hindi', 'Marathi'],
    education: [
      'MBBS - KEM Hospital, Mumbai (2005)',
      'MD Cardiology - AIIMS, New Delhi (2009)',
      'Fellowship in Interventional Cardiology - Mount Sinai, USA (2011)'
    ],
    certifications: [
      'Board Certified Cardiologist',
      'Fellow of American College of Cardiology',
      'Advanced Cardiac Life Support (ACLS)'
    ],
    services: [
      'Cardiac Consultation',
      'Echocardiography',
      'Stress Testing',
      'Angioplasty',
      'Pacemaker Implantation',
      'Heart Surgery'
    ],
    timeSlots: {
      today: ['10:00 AM', '11:30 AM', '2:00 PM', '3:30 PM', '5:00 PM'],
      tomorrow: ['9:00 AM', '10:30 AM', '1:00 PM', '2:30 PM', '4:00 PM'],
      dayAfter: ['10:00 AM', '11:00 AM', '3:00 PM', '4:30 PM']
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/doctors" className="text-blue-600 hover:text-blue-700 flex items-center cursor-pointer">
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Doctors
          </Link>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-sm p-8">
              <div className="flex items-start space-x-6 mb-8">
                <img 
                  src={doctor.image} 
                  alt={doctor.name}
                  className="w-32 h-32 rounded-full object-cover object-top"
                />
                <div className="flex-1">
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{doctor.name}</h1>
                  <p className="text-xl text-blue-600 font-medium mb-2">{doctor.specialty}</p>
                  <p className="text-gray-600 mb-4">{doctor.experience} experience</p>
                  
                  <div className="flex items-center space-x-6 mb-4">
                    <div className="flex items-center space-x-1">
                      <i className="ri-star-fill text-yellow-400"></i>
                      <span className="font-medium">{doctor.rating}</span>
                      <span className="text-gray-500">({doctor.reviews} reviews)</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <i className="ri-hospital-line text-gray-400"></i>
                      <span className="text-gray-600">{doctor.hospital}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <i className="ri-map-pin-line text-gray-400"></i>
                      <span className="text-gray-600">{doctor.location}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {doctor.languages.map((lang) => (
                      <span key={lang} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                        {lang}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="text-2xl font-bold text-gray-900">{doctor.fee}</div>
                    <div className="text-sm text-gray-600">Consultation fee</div>
                  </div>
                </div>
              </div>

              <div className="space-y-8">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">About</h2>
                  <p className="text-gray-700 leading-relaxed">{doctor.about}</p>
                </div>

                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Education</h2>
                  <ul className="space-y-2">
                    {doctor.education.map((edu, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <i className="ri-graduation-cap-line text-blue-600 mt-1"></i>
                        <span className="text-gray-700">{edu}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Certifications</h2>
                  <ul className="space-y-2">
                    {doctor.certifications.map((cert, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <i className="ri-award-line text-blue-600 mt-1"></i>
                        <span className="text-gray-700">{cert}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Services Offered</h2>
                  <div className="grid md:grid-cols-2 gap-3">
                    {doctor.services.map((service, index) => (
                      <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                        <i className="ri-check-line text-green-600"></i>
                        <span className="text-gray-700">{service}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-sm p-6 sticky top-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Book Appointment</h3>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <span className="text-sm font-medium text-green-700">Available Today</span>
                  <span className="text-sm text-green-600">{doctor.timeSlots.today.length} slots</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <span className="text-sm font-medium text-blue-700">Tomorrow</span>
                  <span className="text-sm text-blue-600">{doctor.timeSlots.tomorrow.length} slots</span>
                </div>
              </div>

              <button 
                onClick={() => setShowBooking(true)}
                className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors font-medium cursor-pointer whitespace-nowrap mb-4"
              >
                Book Appointment
              </button>

              <div className="space-y-3">
                <button className="w-full border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap">
                  <i className="ri-phone-line mr-2"></i>
                  Call Doctor
                </button>
                <button className="w-full border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap">
                  <i className="ri-message-2-line mr-2"></i>
                  Send Message
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {showBooking && (
        <AppointmentBooking 
          doctor={doctor} 
          onClose={() => setShowBooking(false)} 
        />
      )}

      <Footer />
    </div>
  );
}
