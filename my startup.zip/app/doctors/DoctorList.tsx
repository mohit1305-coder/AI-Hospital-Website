
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function DoctorList() {
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  const doctors = [
    {
      id: 1,
      name: 'Dr. Priya Sharma',
      specialty: 'Cardiology',
      experience: '15 years',
      rating: 4.8,
      reviews: 234,
      location: 'Mumbai, Maharashtra',
      hospital: 'Apollo Hospital',
      fee: '₹800',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20female%20doctor%20in%20white%20coat%2C%20stethoscope%20around%20neck%2C%20warm%20smile%2C%20modern%20medical%20office%20background%2C%20confident%20and%20approachable%2C%20medical%20charts%20visible%2C%20representing%20cardiology%20specialist&width=120&height=120&seq=doctor-priya-1&orientation=squarish',
      nextAvailable: 'Today, 3:00 PM',
      about: 'Senior Cardiologist with expertise in interventional cardiology and heart surgeries.',
      languages: ['English', 'Hindi', 'Marathi']
    },
    {
      id: 2,
      name: 'Dr. Rajesh Kumar',
      specialty: 'Orthopedics',
      experience: '12 years',
      rating: 4.7,
      reviews: 189,
      location: 'Delhi, India',
      hospital: 'AIIMS Delhi',
      fee: '₹1200',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20male%20doctor%20in%20white%20coat%2C%20confident%20smile%2C%20stethoscope%20around%20neck%2C%20modern%20hospital%20background%2C%20orthopedic%20specialist%2C%20medical%20office%20setting%20with%20bone%20models%20and%20charts&width=120&height=120&seq=doctor-rajesh-1&orientation=squarish',
      nextAvailable: 'Tomorrow, 10:00 AM',
      about: 'Orthopedic surgeon specializing in joint replacements and sports medicine.',
      languages: ['English', 'Hindi', 'Punjabi']
    },
    {
      id: 3,
      name: 'Dr. Anita Patel',
      specialty: 'Dermatology',
      experience: '8 years',
      rating: 4.9,
      reviews: 156,
      location: 'Bangalore, Karnataka',
      hospital: 'Manipal Hospital',
      fee: '₹600',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20female%20dermatologist%20in%20white%20coat%2C%20gentle%20smile%2C%20modern%20dermatology%20clinic%20background%2C%20medical%20equipment%20visible%2C%20skin%20care%20specialist%2C%20clean%20professional%20setting&width=120&height=120&seq=doctor-anita-1&orientation=squarish',
      nextAvailable: 'Today, 5:30 PM',
      about: 'Dermatologist specializing in cosmetic dermatology and skin treatments.',
      languages: ['English', 'Hindi', 'Kannada']
    },
    {
      id: 4,
      name: 'Dr. Arjun Mehta',
      specialty: 'Pediatrics',
      experience: '10 years',
      rating: 4.6,
      reviews: 203,
      location: 'Ahmedabad, Gujarat',
      hospital: 'Sterling Hospital',
      fee: '₹500',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20male%20pediatrician%20in%20white%20coat%2C%20friendly%20smile%2C%20colorful%20pediatric%20clinic%20background%2C%20toys%20and%20children%20drawings%20visible%2C%20child-friendly%20doctor%2C%20warm%20medical%20setting&width=120&height=120&seq=doctor-arjun-1&orientation=squarish',
      nextAvailable: 'Today, 2:00 PM',
      about: 'Pediatrician with expertise in child development and vaccinations.',
      languages: ['English', 'Hindi', 'Gujarati']
    },
    {
      id: 5,
      name: 'Dr. Meera Reddy',
      specialty: 'Gynecology',
      experience: '18 years',
      rating: 4.8,
      reviews: 278,
      location: 'Hyderabad, Telangana',
      hospital: 'Rainbow Hospital',
      fee: '₹900',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20female%20gynecologist%20in%20white%20coat%2C%20compassionate%20smile%2C%20modern%20gynecology%20clinic%20background%2C%20medical%20consultation%20room%2C%20womens%20health%20specialist%2C%20professional%20medical%20setting&width=120&height=120&seq=doctor-meera-1&orientation=squarish',
      nextAvailable: 'Tomorrow, 11:30 AM',
      about: 'Gynecologist specializing in maternal health and minimally invasive surgeries.',
      languages: ['English', 'Hindi', 'Telugu']
    },
    {
      id: 6,
      name: 'Dr. Vikram Singh',
      specialty: 'Neurology',
      experience: '14 years',
      rating: 4.7,
      reviews: 145,
      location: 'Jaipur, Rajasthan',
      hospital: 'Fortis Hospital',
      fee: '₹1000',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20male%20neurologist%20in%20white%20coat%2C%20serious%20yet%20approachable%20expression%2C%20modern%20neurology%20clinic%20background%2C%20brain%20scan%20images%20visible%2C%20specialist%20doctor%2C%20advanced%20medical%20setting&width=120&height=120&seq=doctor-vikram-1&orientation=squarish',
      nextAvailable: 'Today, 4:00 PM',
      about: 'Neurologist specializing in stroke treatment and epilepsy management.',
      languages: ['English', 'Hindi', 'Rajasthani']
    }
  ];

  const handleBookAppointment = (doctor) => {
    setSelectedDoctor(doctor);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Available Doctors</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Sort by:</span>
            <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 pr-8">
              <option>Rating</option>
              <option>Experience</option>
              <option>Fee</option>
              <option>Availability</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {doctors.map((doctor) => (
          <div key={doctor.id} className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow p-6">
            <div className="flex items-start space-x-4">
              <img 
                src={doctor.image} 
                alt={doctor.name}
                className="w-20 h-20 rounded-full object-cover object-top"
              />
              <div className="flex-1">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{doctor.name}</h3>
                    <p className="text-blue-600 font-medium">{doctor.specialty}</p>
                    <p className="text-sm text-gray-600">{doctor.experience} experience</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-1">
                      <i className="ri-star-fill text-yellow-400 text-sm"></i>
                      <span className="text-sm font-medium">{doctor.rating}</span>
                      <span className="text-sm text-gray-500">({doctor.reviews})</span>
                    </div>
                    <p className="text-lg font-bold text-gray-900 mt-1">{doctor.fee}</p>
                  </div>
                </div>

                <div className="mt-3 space-y-2">
                  <div className="flex items-center text-sm text-gray-600">
                    <i className="ri-hospital-line mr-2 w-4 h-4 flex items-center justify-center"></i>
                    {doctor.hospital}
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <i className="ri-map-pin-line mr-2 w-4 h-4 flex items-center justify-center"></i>
                    {doctor.location}
                  </div>
                  <div className="flex items-center text-sm text-green-600">
                    <i className="ri-time-line mr-2 w-4 h-4 flex items-center justify-center"></i>
                    Next available: {doctor.nextAvailable}
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  {doctor.languages.map((lang) => (
                    <span key={lang} className="px-2 py-1 bg-gray-100 text-xs text-gray-600 rounded-full">
                      {lang}
                    </span>
                  ))}
                </div>

                <div className="mt-4 flex space-x-3">
                  <Link href={`/doctors/${doctor.id}`} className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium text-center cursor-pointer whitespace-nowrap">
                    Book Appointment
                  </Link>
                  <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap">
                    View Profile
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 text-center">
        <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium cursor-pointer whitespace-nowrap">
          Load More Doctors
        </button>
      </div>
    </div>
  );
}
